
clc
clear all
% mex cec21_func.cpp -DWINDOWS

format short e;
Runs=30;
fhd=@Parametrized_benchmark_func;
%NP = 100;
optimum= [100, 1100 ,700 ,1900 ,1700 ,1600 ,2100 ,2200 ,2400 ,2500];

% C is the Parametrized Selection Vector, where:
% C1 is Shift indicator (0=0 ,1=F*)
% C2 Translation indicator (0=0, 1=oi)
% C3 Rotation indicator (0=I 1=M)


lb = -100;
ub = 100;
% load Rand_Seeds Rand_Seeds
myCluster = parcluster('local');
myCluster.NumWorkers = 10;  % define how many processors to use
for D = [5 10 15 20]
    Final_results=zeros(10,5);    %% to save the final results
    
    switch D
        case 5
            max_nfes = 50000;
        case 10
            max_nfes = 1000000;
        case 15
            max_nfes = 3000000;
        case 20
            max_nfes = 10000000;
        otherwise
            disp('Error..')
    end
    
    
    for i=1:1
        res=[];
        for func_num=[1:10]
            Par= Introd_Par(func_num,D); %% set of parameters
            Alg_Name=[ 'APGSK_IMODE'];
            funcval_out=zeros(Runs,1);
            fprintf('\n-------------------------------------------------------\n')
            fprintf('Running %s on Function = %d, Dimension size = %d\n',Alg_Name, func_num, D)
            vv=[];
            Conv_Fits=[];
            parfor Run_No=1:Runs
                [Best_solution, BestFit, Conv_Fit,nfes,res] = APGSK_IMODE(max_nfes,lb,ub,func_num,D,fhd,Par,Run_No);
                
%                 if(C(1)==1)
%                     BestFit=BestFit-optimum(func_num);
%                     disp(Conv_Fit')
%                     Conv_Fit=Conv_Fit-optimum(func_num);
                    Conv_Fits=[Conv_Fits,Conv_Fit];
%                 end
                
%                 if(BestFit<1e-8)
%                     BestFit=0;
%                 end
                funcval_out(Run_No) = BestFit;
%                 fprintf('run:%d \t\t BestFit: %e \t\t nfes: %d\n',Run_No ,BestFit,nfes);
                %             file_name=sprintf('Figures\\%s_CEC2017_Problem#%s_problemSize#%s_Run#%s',Alg_Name,int2str(func_num),int2str(Run_No),int2str(D));
                %             save(file_name,'Conv_Fit');
                
                if Par.Printing==1
                    res= res- repmat(Par.f_optimal,size(res,2),1);
                    res(res<=1e-08)=0;
                    ss=size(res,1);
                    endv=res(ss);
                    if size(res,2)<Par.max_nfes
                        res(size(res,1):Par.max_nfes)=endv;
                    end
                    ress=res';
                    vv(Run_No,:)= ress(1:Par.max_nfes);
                end
                ress=[];
            end
            
            %% to print the convergence of ech run % set 0 if not
            
            %             fprintf('min error value = %1.3e, max = %1.3e, median = %1.3e, mean = %1.3e, std = %1.3e\n', min(funcval_out), max(funcval_out), median(funcval_out), mean(funcval_out), std(funcval_out))
            Final_results(func_num,:)= [min(funcval_out),max(funcval_out),median(funcval_out), mean(funcval_out),std(funcval_out)];
            funcval_out=funcval_out';

%             file_name=sprintf('Results/%s_%s_%s.txt',Alg_Name,int2str(func_num),int2str(D));
%             save(file_name,'Conv_Fits', '-ascii');
            
            %% save the results in a text
%             save('results.txt', 'Final_results', '-ascii');
            
                            
        end
    end
    
end
