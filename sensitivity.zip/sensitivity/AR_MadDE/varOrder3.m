function [sums,order]= varOrder3(prev,this,prevDims,thisDims,option)
%VARORDER1 种群中个体的决策变量顺序匹配问题
%   将两种群中个体的每个决策变量到该决策变量均值的平均距离最近的匹配
%prev代表前一种群，mPrev代表前一种群的均值; this代表当前种群，mThis代表当前种群的均值,option代表选择距离最大还是最小
if option==3
    for i=1:thisDims
        order(i)=i;
        sums=0;
    end
elseif option==0
    order=randi(prevDims,1,thisDims);
    sums=0;
elseif option~=0 ||option~=3
sub_pop=length(this);
mPrev=mean(prev);
mThis=mean(this);
temp1=power((prev-mPrev),2);
temp2=power((this-mThis),2);
sum1=sum(temp1,1)/(sub_pop-1);
sum2=sum(temp2,1)/(sub_pop-1);
sums=0;order=zeros(1,thisDims);
if option ==1 
    opt=1;
end
if option ==2 
    opt=2;
end

for i=1:thisDims
    KLD=zeros(1,prevDims);
    for j=1:prevDims
        KLD(j)=log2(power(sum1(j),1/2)/power(sum2(i),1/2))+(sum2(i)+power((mPrev(j)-mThis(i)),2))/(2*sum1(j))-1/2;
    end
    [d,a]=sort(KLD);
    sums=sums+d(opt);
    order(i)=a(opt);
end
end
end
