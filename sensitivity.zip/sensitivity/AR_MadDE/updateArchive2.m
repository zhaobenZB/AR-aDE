% function archive = updateArchive1(archive, pop, funvalue)
function archive= updateArchive2(archive, pop, funvalue)

% archive.funvalues=[archive.funvalues(I==1);archive.funvalues(I==0)];
% archive.pop=[archive.pop(I==1,:);archive.pop(I==0,:)];
% rank=randperm(archive.NP,archive.NP);
% archive.funvalues=archive.funvalues(rank);
% archive.pop=archive.pop(rank,:);
I1 = (archive.funvalues > funvalue);
archive.pop(I1==1,:)=pop(I1==1,:);
archive.funvalues(I1==1)=funvalue(I1==1);
end