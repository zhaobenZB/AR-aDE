function new_pop = m_transfer1(prev,this,prevDims,thisDims,nTransfer,order,option,times)
if nargin ~= 8
        times=0;
end
%M_TRANSFER 决策变量转换函数
prevMax=max(prev,[],1)';
prevMin=min(prev,[],1)';
thisMax=max(this,[],1)';
thisMin=min(this,[],1)';
prevRange=prevMax-prevMin;
thisRange=thisMax-thisMin;
mPrev=mean(prev);
mThis=mean(this);
new_pop=this(1:nTransfer,:);
for i=1:thisDims
    if  option==1 || option==2
        prevMax(order(i))=(prevMax(order(i))-mPrev(order(i)))*(thisRange(i)/prevRange(order(i)))+mPrev(order(i));
        prevMin(order(i))=(prevMin(order(i))-mPrev(order(i)))*(thisRange(i)/prevRange(order(i)))+mPrev(order(i));
    end
end
for n=1:nTransfer
    for i=1:thisDims
        if  option==1 || option==2
            new_pop(n,i)=(prev(n,order(i))-mPrev(order(i)))*(thisRange(i)/prevRange(order(i)))+mPrev(order(i));
        else
            new_pop(n,i)=prev(n,order(i));
        end
        %是否需要减去偏差
        %有交集，且均值在交集中
        if (option==1 || option==2) &&...
                ((prevMin(order(i))<=thisMax(i)&& prevMax(order(i))>=thisMax(i)&& mPrev(order(i))<=thisMax(i))||...
                (prevMax(order(i))>=thisMin(i) && prevMin(order(i))<=thisMin(i) && mPrev(order(i))>=thisMin(i)))
            new_pop(n,i)=new_pop(n,i);%option~=0&&...
        else
            if option~=3
                new_pop(n,i)=new_pop(n,i)+mThis(i)-mPrev(order(i));
            end
        end
    end
end

end

