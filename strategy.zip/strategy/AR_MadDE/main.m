
clc;
clear;
% mex cec21_func.cpp -DWINDOWS

%clear mex;


format long;
Runs = 30;
fhd=@cec20_func;
N = 100;

fistar = [100,1100,700,1900,1700,1600,2100,2200,2400,2500];


func = 1:10;

for D = [5 10 15 20]
    switch D
        case 5
            maxfes = 50000;
        case 10
            maxfes = 1000000;
        case 15
            maxfes = 3000000;
        case 20
            maxfes = 10000000;
        otherwise
            disp('Error..')
    end
    
    fprintf('\n-------------------------------------------------------\n\n')
    AR_MadDE(Runs,fhd,D,func,maxfes,fistar);
end



