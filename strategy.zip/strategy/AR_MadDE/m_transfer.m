function new_pop = m_transfer(prev,this,prevDims,thisDims,nTransfer,order,option)
%M_TRANSFER 决策变量转换函数
mPrev=mean(prev);
mThis=mean(this);
new_pop=prev(1:nTransfer,:);
for n=1:nTransfer
    for i=1:thisDims 
        if option~=3
        new_pop(n,i)=new_pop(n,i)+mThis(i)-mPrev(order(i));
        else
        new_pop(n,i)=new_pop(n,i);    
        end
    end
end

end

