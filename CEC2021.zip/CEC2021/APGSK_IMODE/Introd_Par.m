%% ============ Improved Multi-operator Differential Evolution Algorithm (IMODE) ============
% Should you have any queries, please contact
% Dr. Karam Sallam. Zagazig University
% karam_sallam@zu.edu.eg
% =========================================================================
% Some part of this code is taken from UMOEA-II
% =========================================================================
function [Par] = Introd_Par(I_fno,n,C)

%% loading

Par.n_opr=3;  %% number of operators
Par.n=n;     %% number of decision vriables


if Par.n==10
    Par.CS=50; %% cycle
    Par.max_nfes=200000;
elseif Par.n==20
    Par.CS=50; %% cycle
    Par.max_nfes=1000000;
end
Par.Gmax=1000;

if C(1)==1
    opt= [100, 1100,700,1900,1700,1600,2100,2200,2400,2500];      %% define the optimal solution as shown in the TR
else
    opt=[0,0,0,0,0,0,0,0,0,0]; %% define the optimal solution as shown in the TR
end
Par.xmin= -100*ones(1,Par.n);
Par.xmax= 100*ones(1,Par.n);

Par.f_optimal=opt(I_fno);
Par.PopSize=30*Par.n; %% population size


%% from Ali Code
Par.p_best_rate = 0.5;
Par.p_best_rate_max = Par.p_best_rate;
Par.p_best_rate_min = 0.15;

Par.All_fit=[];
Par.Record_FEs=Par.max_nfes.*[0.01, 0.02, 0.03, 0.05, 0.1:0.1:1];
Par.First_calss_percentage=0.5;
Par.Hybridization_flag=1;

% Par.memory_size=15*Par.n;
% Par.memory_sf = 0.5 .* ones(Par.memory_size, 1);
% Par.memory_cr = 0.5 .* ones(Par.memory_size, 1);
% Par.memory_pos = 1;

% Par.memory_1st_class_percentage = Par.First_calss_percentage.* ones(Par.memory_size, 1); % Class#1 probability for Hybridization

% [CMAES_Par]= CMAES_Init(Par.PopSize,Par.n);
% Par.CMAES_Par=CMAES_Par;

K=[];

Kind=rand(Par.PopSize/4, 1);
%%%%%%%%%%%%%%%%%%%K uniform rand (0,1) with prob 0.5 and unifrom integer [1,20] with prob 0.5
K(Kind<0.5,:)= rand(sum(Kind<0.5), 1);
K(Kind>=0.5,:)=ceil(20 * rand(sum(Kind>=0.5), 1));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Par.All_Imp=zeros(1,4);
Par.K=K;
Par.KW_ind=[];
%% printing the detailed results- this will increase the computational time
Par.Printing=0; %% 1 to print; 0 otherwise

end