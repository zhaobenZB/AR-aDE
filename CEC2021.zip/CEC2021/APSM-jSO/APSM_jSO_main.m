% The MATLAB source code of APSM-jSO is developed in MATLAB R2019b with 64 bits. 
% Please run this code on MATLAB2019b or later with 64 bits. 
% Please cite this article as: Yintong Li, Tong Han, Huan Zhou, Yujie Wei, Yuan Wang, Mulai Tan, Changqiang Huang. 
% APSM-jSO: A novel jSO variant with an adaptive parameter selection mechanism and a new external archive updating mechanism.
% Swarm and Evolutionary Computation, https://doi.org/10.1016/j.swevo.2023.101283.
close all
clear
clc
format long
fobj=str2func('Parametrized_benchmark_func');
F_NUM=10;
Fmin=[100, 1100, 700, 1900, 1700, 1600, 2100, 2200, 2400, 2500];
dims=[10 20];
FEsmaxs=[200000,1000000];
lb=-100;
ub=100;
iter=30;
Best_fitness=zeros(1,30);
C = [
    0 0 0;
    0 0 1;
    0 1 0;
    0 1 1;
    1 0 0;
    1 0 1;
    1 1 0;
    1 1 1;
    ];


for func_num=1:10
    for D=1:2
        dim=dims(D);FEsmax=FEsmaxs(D);
        SearchAgents_no=ceil(75*dim^(2/3));
    for i=1:size(C,1)
    Alg_Name=[ 'APSM-jSO_(' num2str(C(i,1)) num2str(C(i,2)) num2str(C(i,3)) ')'];
    parfor repeat=1:iter
        %---------------------main--------------------------
        [Best_score,Best_pos,Convergence]=APSM_jSO(SearchAgents_no,FEsmax,lb,ub,dim,fobj,func_num,C(i,:));
        if (C(i,1)==1); Best_fitness(repeat)=Best_score-Fmin(func_num); end
        
        
        %-----------------------end--------------------
    end
    
    fprintf('min_funvals:\t%e\n',min(Best_fitness));
    fprintf('median_funvals:\t%e\n',median(Best_fitness));
    fprintf('mean_funvals:\t%e\n',mean(Best_fitness));
    fprintf('max_funvals:\t%e\n',max(Best_fitness));
    fprintf('std_funvals:\t%e\n',std(Best_fitness));
    % Saving the solutions
    file_name=sprintf('Results/%s_%s_%s.txt',Alg_Name,int2str(func_num),int2str(dim));
    save(file_name, 'Best_fitness', '-ascii');
    end
    end
end
% disp(Best_fitness)




